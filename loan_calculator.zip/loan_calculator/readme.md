# Loan calculator

* use a  shortcode `[loan_calculator]` on wordpress to connect the plugin.



